def test_function():
    return 42
